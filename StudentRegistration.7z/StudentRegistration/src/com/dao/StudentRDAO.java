package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.jd.model.Student;

public class StudentRDAO {
    String studentName = null;
	int studentAge = 0;
	long studentMobileNo = 0;
	String studentAddress = null;
	public void insert(StudentRegistration s, Student st) {
		try {
			String drivername = s.getDbdrivername();
			System.out.println("Driver name" + drivername);
			String url = s.getDburl();
			String username = s.getDbusername();
			String password = s.getDbpassword();
			Class.forName(drivername);
			Connection con = DriverManager.getConnection(url, username, password);
			String sqlquery = "Insert into StudentRegistration values(?, ? , ?, ?)";
		    PreparedStatement pstmt = con.prepareStatement(sqlquery);
			studentName = st.getStudentName();
			studentAge = st.getStudentAge();
			studentMobileNo = st.getStudentMobileNo();
			studentAddress = st.getStudentAddress();
			
			pstmt.setString(1, studentName);
			pstmt.setInt(2, studentAge);
			pstmt.setLong(3, studentMobileNo);
			pstmt.setString(4, studentAddress);
			
		    pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
