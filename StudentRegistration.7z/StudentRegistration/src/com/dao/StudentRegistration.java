package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class StudentRegistration {
	 
	private String dbdrivername;
	private String dburl;
	private String dbusername;
	private String dbpassword;
	
	
	public StudentRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentRegistration(String dbdrivername, String dburl, String dbusername, String dbpassword) {
		super();
		this.dbdrivername = dbdrivername;
		this.dburl = dburl;
		this.dbusername = dbusername;
		this.dbpassword = dbpassword;
	}

	public String getDbdrivername() {
		return dbdrivername;
	}

	public void setDbdrivername(String dbdrivername) {
		this.dbdrivername = dbdrivername;
	}

	public String getDburl() {
		return dburl;
	}

	public void setDburl(String dburl) {
		this.dburl = dburl;
	}

	public String getDbusername() {
		return dbusername;
	}

	public void setDbusername(String dbusername) {
		this.dbusername = dbusername;
	}

	public String getDbpassword() {
		return dbpassword;
	}

	public void setDbpassword(String dbpassword) {
		this.dbpassword = dbpassword;
	}
	
}
