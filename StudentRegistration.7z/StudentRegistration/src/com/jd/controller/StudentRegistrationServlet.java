package com.jd.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.StudentRDAO;
import com.dao.StudentRegistration;
import com.jd.model.Student;

/**
 * Servlet implementation class StudentRegistrationServlet
 */
@WebServlet("/studentregistration")
public class StudentRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		String studentName = request.getParameter("name");		
		int studentAge = Integer.parseInt(request.getParameter("age")); 
		long studentMobileNo = Long.parseLong(request.getParameter("mobileNo"));
		String studentAddress = request.getParameter("Address");	
		Student student = new Student(studentName, studentAge, studentMobileNo, studentAddress);
		request.setAttribute("StudentObj", student);
		
		ServletContext scontect = request.getServletContext();
		String drivername = scontect.getInitParameter("dbdrivername");
		String url = scontect.getInitParameter("dburl");
		String username = scontect.getInitParameter("dbusername");
		String password = scontect.getInitParameter("dbpassword");
		StudentRegistration stdao = new StudentRegistration(drivername,url,username,password);
		StudentRDAO daoobj = new StudentRDAO();
		daoobj.insert(stdao, student);
		
		RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
		rd.forward(request, response);
		
		
	}

}
