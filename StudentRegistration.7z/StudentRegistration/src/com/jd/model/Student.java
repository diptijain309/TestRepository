package com.jd.model;

public class Student {

	private String studentName;
	private int studentAge;
	private long studentMobileNo;
	private String studentAddress;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Student(String studentName, int studentAge, long studentMobileNo, String studentAddress) {
		super();
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.studentMobileNo = studentMobileNo;
		this.studentAddress = studentAddress;
	}


	public String getStudentName() {
		return studentName;
	}


	public int getStudentAge() {
		return studentAge;
	}


	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}




	public long getStudentMobileNo() {
		return studentMobileNo;
	}


	public void setStudentMobileNo(int studentMobileNo) {
		this.studentMobileNo = studentMobileNo;
	}


	public String getStudentAddress() {
		return studentAddress;
	}


	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}
	

}
