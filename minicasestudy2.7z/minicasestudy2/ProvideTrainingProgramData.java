package minicasestudy2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ProvideTrainingProgramData {
	
	public List<NewTrainingProgram> trProgram;
	
		List<String> months_str = Arrays.asList("January", "February", "March", "April", "May", "June", "July",
			    "August", "September", "October", "November", "December");

	
	public void enterTrainingProgramDetails() throws Exception{
		trProgram = new ArrayList<> ();
				Scanner scr1 = new Scanner(System.in);
				System.out.println("Enter the program code");
				String programcode = scr1.next();
				
				// Sql query to check for existing module code.
				Connection conn = DBUtils.buildConnection();
				String sqlquery0 = "select * from ProgramModule where moduleCode = ?";
				PreparedStatement prstmt0 = conn.prepareStatement(sqlquery0);
				prstmt0.setString(1, programcode);
				ResultSet result = prstmt0.executeQuery();
				if(result != null){
					System.out.println("Record already exists.");
					DuplicateCodeException ex = new DuplicateCodeException("Duplicate program code", programcode);
					return ;
				}
				
				// Continue execution.
				System.out.println("Enter the name of the program");
				String programname = scr1.next();
				System.out.println("Enter the month");
				String month = scr1.next();
				if(!months_str.contains(month)){
					System.out.println("Record already exists.");
					InvalidMonthException ex = new InvalidMonthException("Month does not exists", month);
					return ;
				}
				
				System.out.println();
				
				//Connection conn = DBUtils.buildConnection();
				String sqlquery = "Insert into TrainingProgram values(?, ? , ?)";
				PreparedStatement prstmt = conn.prepareStatement(sqlquery);
				
				prstmt.setString(1, programcode); 
				prstmt.setString(2, programname); 
				prstmt.setString(3, month); 
				
				int count = prstmt.executeUpdate();
				System.out.println("Record updated: " +count);
			}

		}
	
