package minicasestudy2;

public class DummyMain {

	public static void main(String[] args) {
		SelectMenu menu = new SelectMenu();
		
		while(true){
		menu.selectMenus();
		}
	}

}
