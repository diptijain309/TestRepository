package minicasestudy2;

import java.util.Scanner;

public class SelectMenu {
	
	ProvideTrainingModuleData moduledata = new ProvideTrainingModuleData();
	ProvideTrainingProgramData programdata = new ProvideTrainingProgramData();

	
public void selectMenus() throws Exception{
	
	System.out.println("Select any of the below menu: ");
	System.out.println("01 Create New Training Module");
	System.out.println("02 Create New Training Program");
	System.out.println("03 Link Training Module to Training Program");
	System.out.println("04 Display Total Financial Budget");
	System.out.println("05 Display Budget According To Month");
	System.out.println("06 Exit");
	System.out.println();
	
	Scanner scr = new Scanner(System.in);
	int selectoption = scr.nextInt();
	switch(selectoption){
	case 01:
		System.out.println("Welcome to Create New Training Module Home Page");
		moduledata.enterTrainingModuleDetails();
		break;
		
	case 02:
		System.out.println("Welcome to Create New Training Program Home Page");	
		programdata.enterTrainingProgramDetails();
		break;
		
	case 03:
		System.out.println("Link Training Module to Training Program");	
		break;
		
	case 04:
		System.out.println("Display Total Financial Budget");	
		break;
		
	case 05:
		System.out.println("Display Budget According To Month");	
		break;
		
	case 06:
		System.out.println("Exit");	
		System.exit(1);
		break;
		
	default:
			
		System.out.println("Please select correct menu option");
		break;
	}	


}

}
