package minicasestudy2;

public class NewTrainingModule {
	private String module_code;
	private String name;
	private int duration;
	private double budgetperday;
	
	public NewTrainingModule() {
		super();
	}

	public NewTrainingModule(String module_code, String name, int duration, double budgetperday) {
		super();
		this.module_code = module_code;
		this.name = name;
		this.duration = duration;
		this.budgetperday = budgetperday;
	}

	public String getModule_code() {
		return module_code;
	}

	public void setModule_code(String module_code) {
		this.module_code = module_code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getBudgetperday() {
		return budgetperday;
	}

	public void setBudgetperday(double budgetperday) {
		this.budgetperday = budgetperday;
	}
	
	

}
