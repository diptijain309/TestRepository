package minicasestudy2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
	public static String DriverName;
	public static Connection buildConnection() throws Exception{
		DriverName = "oracle.jdbc.OracleDriver";
			Class.forName(DriverName);
			String url = " ";
			String username = "system";
			String password = "12345";
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("Driver connected successfully.");
			return con;					
		
	}

}
