package minicasestudy2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProvideTrainingModuleData {
	public List<NewTrainingModule> trModule;

	
	public void enterTrainingModuleDetails() throws Exception{
			trModule = new ArrayList<> ();
				Scanner scr1 = new Scanner(System.in);
				System.out.println("Enter the module code");
				String modulecode = scr1.next();
				Connection conn = DBUtils.buildConnection();
				String sqlquery0 = "select * from TrainingModule where moduleCode = ?";
				PreparedStatement prstmt0 = conn.prepareStatement(sqlquery0);
				prstmt0.setString(1, modulecode);
				ResultSet result = prstmt0.executeQuery();
				if(result != null){
					System.out.println("Record already exists.");
					DuplicateCodeException ex = new DuplicateCodeException("Duplicate module code", modulecode);
					return ;
				}
				System.out.println("Enter the name of the module");
				String modulename = scr1.next();
				System.out.println("Enter the duration");
				int duration = scr1.nextInt();
				System.out.println("Enter the budget per day");
				double budgetperday = scr1.nextDouble();
				System.out.println();

				//System.out.println(modulecode + " " +modulename + " " +duration  + " " + budgetperday);
				trModule.add(new NewTrainingModule(modulecode, modulename, duration, budgetperday));
				
				//Connection conn = DBUtils.buildConnection();
				String sqlquery = "Insert into TrainingModule values(?, ? , ?, ?)";
				PreparedStatement prstmt = conn.prepareStatement(sqlquery);
				
				prstmt.setString(1, trModule.get(0).getModule_code()); 
				prstmt.setString(2, trModule.get(0).getName()); 
				prstmt.setInt(3, trModule.get(0).getDuration()); 
				prstmt.setDouble(4, trModule.get(0).getBudgetperday()); 
				
				int count = prstmt.executeUpdate();
				System.out.println("Record updated: " +count);

	}
	
}

	
	