package minicasestudy2;

public class DuplicateCodeException extends Exception{
	
	String duplicateModuleCode;
	String errormessage;
	
	public DuplicateCodeException(String errormessage, String duplicateModuleCode) {
		this.duplicateModuleCode = duplicateModuleCode;
		this.errormessage = errormessage;
	}
	
	
	public String getMessage() {
		String msg = super.getMessage();
		return (msg + " " + duplicateModuleCode);
	}
	

}


 class InvalidMonthException extends Exception{
	
	String invalidMonth;
	String errormessage;
	
	public InvalidMonthException(String errormessage, String invalidMonth) {
		this.invalidMonth = invalidMonth;
		this.errormessage = errormessage;
	}
	
	
	public String getMessage() {
		String msg = super.getMessage();
		return (msg + " " + invalidMonth);
	}
	

}