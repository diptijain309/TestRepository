package minicasestudy2;

public class NewTrainingProgram {
	private String programCode;
	private String programName;
	private String month;
	public NewTrainingProgram(String programCode, String programName, String month) {
		super();
		this.programCode = programCode;
		this.programName = programName;
		this.month = month;
	}
	
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
	

}
